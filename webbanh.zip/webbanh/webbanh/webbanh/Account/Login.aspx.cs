﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using webbanh.Model;

namespace webbanh.Account
{
    public partial class Login : System.Web.UI.Page
    {
        private readonly object username;
        private readonly string password;
        
        private string pwd;

        public string Username { get; private set; }
        public bool Password { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
       

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            var _db = new webbanh.Model.ProductContext();
            IQueryable<Order> query = _db.Orders;
            webbanh.Logic.ShoppingCartActions usersShoppingCart = new webbanh.Logic.ShoppingCartActions();
            String cartId = usersShoppingCart.GetCartId();
            usersShoppingCart.MigrateCart(cartId,Username);
            if ( Username=="admin")
            {
                Session["username"] = Username;
                Response.Redirect("~/Admin/AdminPage");

            }
            else
            {
                Session["username"] = Username;
                Response.Redirect("~/Site");
            }
            /* if (username == "admin" && pwd == "123")
             {

                 Session["username"] = username;
                 Response.Redirect("~/Admin/AdminPage");
             }
             else
             {
                 Session["username"] = username;
                 Response.Redirect("~/Site");
             }*/


        }
    }
}