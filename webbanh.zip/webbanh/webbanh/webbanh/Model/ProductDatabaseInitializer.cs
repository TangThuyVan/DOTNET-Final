﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;


namespace webbanh.Model
{
    public class ProductDatabaseInitializer : DropCreateDatabaseIfModelChanges<ProductContext>
    {

        protected override void Seed(ProductContext context)
        {
            GetCategories().ForEach(c => context.Categories.Add(c));
            GetProducts().ForEach(p => context.Products.Add(p));
            
        }
        private static List<Category> GetCategories()
        {
            var categories = new List<Category>
                {
                    new Category
                    {
                        CategoryID = 1,
                    CategoryName = "banhman",
                    ImagePaths="banhman.banhmi.png"

                    },
                    new Category
                {
                    CategoryID = 2,
                    CategoryName = "banhngot",
                    ImagePaths="banhngot..banhkem.jpg"
                },
                new Category
                {
                    CategoryID = 3,
                    CategoryName = "banhbao",
                    ImagePaths="banhman-banhbao.jpg"
                },
                };
            return categories;

        }
        private static List<Product> GetProducts()
        {
            var products = new List<Product>
                {
                     new Product
                     {
                    ProductID = 1,
                    ProductName = "Bánh Mì",

                    ImagePath="banhman.banhmi.png",
                    UnitPrice = 10.000,
                    CategoryID = 1
                     },
                      new Product
                     {
                    ProductID = 2,
                    ProductName = "Bánh Kem",

                    ImagePath="banhngot..banhkem.jpg",
                    UnitPrice = 100.000,
                    CategoryID = 2
                     },
                       new Product
                     {
                    ProductID = 3,
                    ProductName = "Bánh Bao",

                    ImagePath="banhman-banhbao.jpg",
                    UnitPrice = 100.000,
                    CategoryID = 3
                     },

                };
            return products;

        }


    }
}