﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace webbanh.Model
{
    public class TK
    {
        [ScaffoldColumn(false),Key]

        public string TenID { get; set; }

        [Required, StringLength(100), Display(Name = "Name")]
        public string HoTen { get; set; }

        [Required, StringLength(10000), Display(Name = "MatKhau"), DataType(DataType.MultilineText)]
        public string MatKhau { get; set; }

        [Required, StringLength(10000), Display(Name = "sdt"), DataType(DataType.MultilineText)]
        public string SDT { get; set; }

        [Required, StringLength(10000), Display(Name = "gioitinh"), DataType(DataType.MultilineText)]
        public string GioiTinh { get; set; }

        

        public virtual ICollection<TK> TKs { get; set; }
    }
}