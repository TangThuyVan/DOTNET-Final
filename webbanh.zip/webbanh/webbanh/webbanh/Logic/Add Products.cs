﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using webbanh.Model;

namespace webbanh.Logic
{
    public class Add_Products
    {
        public bool AddProduct(string ProductID, string ProductName,  string ProductPrice, string ProductCategory, string ProductImagePath)
        {
            var myProduct = new Product();
            myProduct.ProductID = Convert.ToInt32(ProductID);
            myProduct.ProductName = ProductName;
            
            myProduct.UnitPrice = Convert.ToDouble(ProductPrice);
            myProduct.ImagePath = ProductImagePath;
            myProduct.CategoryID = Convert.ToInt32(ProductCategory);

            using (ProductContext _db = new ProductContext())
            {
                // Add product to DB.
                _db.Products.Add(myProduct);
                _db.SaveChanges();
            }
            // Success.
            return true;
        }
    }
}