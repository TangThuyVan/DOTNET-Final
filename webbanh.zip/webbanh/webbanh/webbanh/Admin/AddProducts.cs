﻿using System;

namespace webbanh.Admin
{
    internal class AddProducts
    {
        internal bool AddProduct(string text1, string text2, string text3, string selectedValue, string fileName)
        {
            throw new NotImplementedException();
        }

        internal bool AddProduct(string text1, string text2, string selectedValue, string fileName)
        {
            throw new NotImplementedException();
        }
    }
}